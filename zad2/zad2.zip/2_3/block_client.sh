docker run -it --rm --network-alias z44_z23_c_client_block --network z44_network --name z44_z23_c_client_block z44_z23_c_client_block:latest z44_z23_py_server 8000
