docker build --tag z44_z23_c_client_block ../2_1/client_c
docker build --tag z44_z23_c_client ./client_c
docker build --tag z44_z23_py_server ./server_py