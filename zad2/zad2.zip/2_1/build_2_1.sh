docker build --tag z44_z21_c_client ./client_c
docker build --tag z44_z21_c_server ./server_c
docker build --tag z44_z21_py_client ./client_py
docker build --tag z44_z21_py_server ./server_py
